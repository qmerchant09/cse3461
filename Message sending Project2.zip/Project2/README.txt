QUANTEZ MERCHANT PROJECT 2: MESSAGE SENDING README

- To run this program, run make client to create the client for use. 
- In another terminal window start the server.
- The server requires a port number to be specified when calling it. 
- After the server is running, start the client in the original window. 
- The client requires an IP Address and a port number that corresponds to the port number used by the server. 
- The client will prompt you for a message, after entering it in the client will talk to the server.
- The server will respond with the size of the message on its end and start to recieve the message.
